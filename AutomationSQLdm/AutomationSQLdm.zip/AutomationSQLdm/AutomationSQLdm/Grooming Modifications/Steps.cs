﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Threading;
using WinForms = System.Windows.Forms;

using Ranorex;
using Ranorex.Core;
using Ranorex.Core.Testing;

using AutomationSQLdm.Commons;
using AutomationSQLdm.Extensions;
using AutomationSQLdm.Configuration;

namespace AutomationSQLdm.Grooming_Modifications
{
    [TestModule("5832C0D8-1C2E-4CBF-B426-859040845D52", ModuleType.UserCode, 1)]
    public static class Steps 
    {
   		public static GroomingRepo repo = GroomingRepo.Instance;
		public const string GROOMING_MENU = @"/contextmenu[@processname='SQLdmDesktopClient']/menuitem[@automationid='menuToolsGrooming']";
      
        public static void ClickOnTools()
		{
			try 
			{
				repo.Application.ToolsInfo.WaitForExists(new Duration(1000000));
				repo.Application.Tools.Click();
				Reports.ReportLog("ClickOnTools", Reports.SQLdmReportLevel.Success, null, Config.TestCaseName);
			} 
			catch (Exception ex)
			{
				throw new Exception("Failed : ClickOnTools :" + ex.Message);
			}
		}
        
        public static void SelectGroomingOption()
		{ 
			try
			{
				Ranorex.MenuItem groomingMenuItem = GROOMING_MENU;
				if(groomingMenuItem != null) groomingMenuItem.ClickThis();
				Reports.ReportLog("SelectGroomingOption", Reports.SQLdmReportLevel.Success, null, Config.TestCaseName);
			}
			catch (Exception ex)
			{
				throw new Exception("Failed : SelectGroomingOption :" + ex.Message);
			}
		}

       
        public static void VerifyAggregateforecastingValue()
		{
			try 
			{
				repo.GroomingOptionWindow.SelfInfo.WaitForExists(new Duration(1000000));
				if (repo.GroomingOptionWindow.AggregateTextboxInfo.Exists())
					Reports.ReportLog("Verify Aggregate forecasting data to daily records after is Displaying: " + repo.GroomingOptionWindow.AggregateTextbox.TextValue , Reports.SQLdmReportLevel.Success, null, Config.TestCaseName);
				else
					Reports.ReportLog("Verify Aggregate forecasting data to daily records after", Reports.SQLdmReportLevel.Info, null, Config.TestCaseName);
			} 
			catch (Exception ex)
			{
				throw new Exception("Failed : VerifyAggregateforecastingValue :" + ex.Message);
			}
		}
        
        
        public static void VerifyGroomforecastingValue()
		{
			try 
			{
				repo.GroomingOptionWindow.SelfInfo.WaitForExists(new Duration(1000000));
				if (repo.GroomingOptionWindow.GroomForecastTextboxInfo.Exists())
					
					Reports.ReportLog("Groom forecasting data to daily records after is Displaying : " + repo.GroomingOptionWindow.GroomForecastTextbox.TextValue, Reports.SQLdmReportLevel.Success, null, Config.TestCaseName);
				else
					Reports.ReportLog("Groom forecasting data to daily records after", Reports.SQLdmReportLevel.Info, null, Config.TestCaseName);
			} 
			catch (Exception ex)
			{
				throw new Exception("Failed : VerifyAggregateforecastingValue :" + ex.Message);
			}
		}

 		public static void ClickOnCancel()
		{
			try 
			{	
				repo.GroomingOptionWindow.CancelButtonInfo.WaitForExists(new Duration(1000000));
				repo.GroomingOptionWindow.CancelButton.Click();
				Reports.ReportLog("Click On Cancel Button", Reports.SQLdmReportLevel.Success, null, Config.TestCaseName);
			} 
			catch (Exception ex)
			{
				throw new Exception("Failed : ClickOnCancel :" + ex.Message);
			}
		}
 		
 		 public static void VerifyQueryIsRemovedFromText()
		{
			try 
			{
				//Verify Query is Removed from The Current time on the repository
				repo.GroomingOptionWindow.SelfInfo.WaitForExists(new Duration(1000000));
				
				if (repo.GroomingOptionWindow.GroomForecastTextboxInfo.Exists())
					
					Reports.ReportLog("The Current time on the repository is Displaying : " + repo.GroomingOptionWindow.GroomForecastTextbox.TextValue, Reports.SQLdmReportLevel.Success, null, Config.TestCaseName);
				else
					Reports.ReportLog("Query is not Removed from The Current time on the repository", Reports.SQLdmReportLevel.Info, null, Config.TestCaseName);
			} 
			catch (Exception ex)
			{
				throw new Exception("Failed : VerifyQueryIsRemovedFromText :" + ex.Message);
			}
		}
    }
}
